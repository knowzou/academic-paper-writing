# Final Report: Academic Paper Writing Skill Upgrade

## Executive Summary

The `academic-paper-writing` Claude Code skill has been upgraded from a generic 4-reviewer system (Baseline, 980 lines) to a maximalist high-rigor 6-reviewer system (V3, 3449 lines) through a systematic 3-version development and evaluation process. V3 scores 4.58/5.00 across 12 evaluation cases grounded in a real ICML 2026 paper (DLM-Scope), representing a +2.31 point improvement over the 2.27 baseline. V3 is now deployed to production.

---

## 1. Project Scope

**Objective**: Upgrade the academic paper review-and-revision skill to maximize professional rigor, review accuracy, harsh-but-fair top-venue reviewer behavior, and deep logical consistency, with the multi-reviewer + multi-round loop as the non-negotiable core strength.

**Four highest-priority upgrade axes**:
1. Reviewer Persona Design
2. Aggregation Mechanism
3. Multi-Round Unresolved Issue Tracking
4. Theory/Experiments Dual-Core Review System

---

## 2. Version Inventory

| Version | Files | Lines | Architecture |
|---------|-------|-------|-------------|
| Baseline (original) | 3 | 980 | 4 generic reviewers, mechanical aggregation |
| V1 (conservative) | 4 | 921 | 4 reviewers + specialization hints, 7-item superficial-fix detection |
| V2 (structural) | 4 | 2344 | 6 dedicated specialists, cross-core coordination, meta-reviewer |
| **V3 (maximalist)** | **6** | **3449** | **6 maximally specified specialists, 15-item protocol files, false convergence detection, debt trackers** |

---

## 3. What the Baseline Gets Right

- The Historical/Fresh reviewer split is a sound bias-reduction mechanism that all versions preserve
- The 5-dimension scoring framework (Story/Logic, Theory/Rigor, Evidence, Writing/Structure, References/Positioning) is comprehensive and well-calibrated
- The multi-round revision loop with pass condition is architecturally correct
- The 6-agent revision team (Theory, Experiment, Writing, Layout, Story, Reference) is well-designed
- Faithfulness guardrails (don't fabricate issues) are adequate (4.00/5.00)

---

## 4. What the Baseline Gets Wrong

- **Generic reviewers** (D03: 1.75/5): All 4 reviewers follow identical instructions. No reviewer is specifically responsible for theory depth, experiment rigor, writing quality, or structural completeness.
- **No theory-specific review** (D06: 1.00/5): No instructions to check theorem completeness, proof soundness, notation consistency, or to distinguish engineering formulations from theoretical contributions.
- **No experiment-specific review** (D07: 1.33/5): No instructions to check baseline fairness, statistical credibility, ablation completeness, or claim-number alignment.
- **No cross-core coordination** (D08: 1.00/5): No mechanism to detect misalignment between abstract claims and supporting evidence.
- **Weak issue tracking** (D05: 1.50/5): Minimal issue schema, no superficial-fix detection, no structured audit of whether fixes are genuine.
- **No multi-round safeguards** (D11: 1.50/5): No false convergence detection, no anti-superficial-fix protocol, Historical reviewers have no structured method to verify prior-round fixes.

---

## 5. V1 Design and Contributions

**Design hypothesis**: Small, targeted improvements to the 4-reviewer system can significantly address the most common failure modes without changing architecture.

**Key innovations**:
- **Reviewer specialization hints**: 2 theory-leaning + 2 experiments-leaning reviewers. Same 4-reviewer count, but each pair applies a domain-specific checklist.
- **10-item theory checklist**: Covers theorem completeness, proof soundness, assumption realism, notation consistency, derivation chain clarity, hidden assumptions, approximation justification, claim-guarantee alignment, prior work comparison, engineering vs theory distinction.
- **10-item experiments checklist**: Covers claim-number alignment, baseline fairness, ablation completeness, statistical credibility, reproducibility details, metric appropriateness, failure case reporting, result interpretation honesty, scale appropriateness, comparison completeness.
- **12-field issue schema**: issue_id, title, severity, category, reviewers_flagging, first/last_seen_round, evidence_locations, summary, impact_on_acceptance, proposed_fix_agent, resolution_status, resolution_evidence, reopen_conditions.
- **7-item superficial-fix detection protocol**: For Historical reviewers to systematically detect wording-only edits, claim softening without new analysis, and other surface-level patches.
- **Enhanced convergence**: Score threshold + no open CRITICAL + all MAJOR resolved or deferred.

**Evaluation result**: 3.05/5.00 (+0.78 over baseline)

**Breakout case**: C09 (multi-round verification): 3.95 vs baseline 1.72 (+2.23). The superficial-fix protocol is the single highest-ROI improvement across all versions.

---

## 6. V2 Design and Contributions

**Design hypothesis**: Dedicated specialist reviewers produce non-overlapping reviews with deeper insights. Cross-core coordination catches issues no single reviewer would find.

**Key innovations**:
- **6 specialized reviewers** (2+2+1+1 structure):
  - Theory Historical + Theory Fresh: dedicated theory pair
  - Experiments Historical + Experiments Fresh: dedicated experiments pair
  - Writing & Argument (always fresh): dedicated narrative quality
  - Structure & Reproducibility (always fresh): dedicated formatting/reproducibility
- **Cross-core coordination phase**: Explicit post-review phase constructing a claim-evidence matrix before aggregation. Compares theory claims against experiment evidence systematically.
- **Meta-reviewer aggregation**: Planner acts as area chair with 4-tier consensus classification (unanimous → auto-CRITICAL; strong consensus → retain highest severity; majority → retain with note; minority → retain at severity-1 with specialist note).
- **Specialist weighting**: Theory reviewer findings on theory issues carry more weight than non-specialist findings, and vice versa.
- **Full issue lifecycle**: open → acknowledged → in_progress → partially_resolved → resolved → reopened. Auto-escalation after 3 rounds unresolved.
- **V2 pass condition**: Scores + no CRITICAL + no 2-round MAJOR + no blocking cross-core + resolution rate >= 80%.

**Evaluation result**: 4.10/5.00 (+1.05 over V1)

**Breakout case**: C06 (cross-core audit): 4.33 vs V1 2.37 (+1.96). The dedicated cross-core phase is transformative — it reveals that 3 of 6 abstract claims in the DLM-Scope paper have significant support issues.

---

## 7. V3 Design and Contributions

**Design hypothesis**: Maximum specification of reviewer behavior, combined with the strongest possible issue tracking and false convergence prevention, produces the highest-quality outcomes.

**Key innovations over V2**:
- **Dedicated protocol files**: `theory-review-protocol.md` (393 lines, 15-item checklist + proof verification methodology + notation audit + claim-guarantee alignment matrix + 10-item anti-superficial-fix rubric + theory debt tracking) and `experiments-review-protocol.md` (436 lines, 15-item checklist + claim-evidence alignment matrix + baseline fairness audit + ablation completeness audit + statistical credibility checklist + reproducibility audit + 10-item anti-superficial-fix rubric).
- **Confidence levels**: Every finding rated HIGH/MEDIUM/LOW confidence. Enables meta-reviewer to weight uncertain findings appropriately.
- **False convergence detection**: Three patterns: (1) scores improve but issue count is flat, (2) Fresh reviewers rediscover issues marked "resolved" by Historical reviewers, (3) writing/structure scores improve but theory/evidence scores don't.
- **Debt trackers**: theory_debt.yaml and experiment_debt.yaml accumulate residual weakness signals across rounds with severity trends and overall health assessment.
- **15+ field issue schema**: Adds severity_history, resolution_history (per-round), dependencies, blocks_acceptance, subcategory, confidence per reviewer.
- **Extended lifecycle**: 6 states + verified_resolved + superseded. Evidence-based transitions.
- **V3 pass condition** (8 conditions): All V2 conditions + no false-convergence flags + genuine-improvement confirmation from Historical + debt health not critical.

**Evaluation result**: 4.58/5.00 (+0.48 over V2)

**Breakout cases**: C04/C05 (theory/experiments core): 4.88 each. C09 (multi-round): 4.97. The 15-item protocol files ensure comprehensive coverage, and false convergence detection prevents premature acceptance.

---

## 8. Why V3 Won

V3 wins or ties every single case against every other version. The critical differentiators:

1. **False convergence detection is unique to V3** and addresses the most dangerous review failure mode — declaring a paper "improved" when it's merely been polished.

2. **15-item dedicated protocol files** vs V2's 12-item in-document checklists ensure nothing is skipped. The separate `.md` files are loaded as references and always available to the reviewer, not embedded in instructions that may be truncated.

3. **Confidence-level reporting** enables the meta-reviewer to distinguish "this might be an issue" from "this is definitely a problem," producing more calibrated aggregation.

4. **Debt trackers** accumulate signals across rounds, making it impossible for a recurring weak area to be hidden by fixing individual issues.

5. **The 10-item anti-superficial-fix rubrics** (per domain) are far more comprehensive than V1's 7-item general checklist or V2's inherited protocol.

---

## 9. Why Multi-Reviewer + Multi-Round Matters (10 Questions Answered)

### Q1: Do multiple reviewers catch non-overlapping issues?

**Yes.** In C01 (full review), theory-leaning/dedicated reviewers catch the "no theorems" gap while experiments-leaning/dedicated reviewers catch the unfair steering comparison. In V3, the Writing & Argument reviewer independently catches the "4 studies stapled together" narrative issue that neither theory nor experiments reviewers flag.

### Q2: Does the Historical/Fresh split reduce bias?

**Yes.** Historical reviewers provide continuity (tracking prior-round issues) while Fresh reviewers provide independence (catching issues that Historical reviewers may have anchored past). C09 shows this concretely: a Fresh experiment reviewer in round 2 independently rediscovers the statistical evidence gap, confirming it's real and not Historical reviewer stubbornness.

### Q3: Does reviewer specialization improve issue discovery?

**Yes, substantially.** Baseline (generic) scores 1.00 on Theory Review Strength; V1 (hints) scores 3.00; V2 (dedicated) scores 4.00; V3 (maximally specified) scores 5.00. Each level of specialization catches additional issues.

### Q4: Does cross-core coordination catch issues individual reviewers miss?

**Yes.** C06 demonstrates this definitively. No individual reviewer reliably catches that 3 of 6 abstract claims have significant support issues. The claim-evidence matrix constructed in V2/V3's cross-audit phase makes this explicit.

### Q5: Does superficial-fix detection work?

**Yes.** C09 shows that baseline Historical reviewers accept a wording change ("correlate" → "are consistent with") as partially addressing a concern. V1's 7-item protocol catches this as a wording-only edit. V3's 10-item rubric escalates it to CRITICAL.

### Q6: Does false convergence detection prevent premature acceptance?

**Yes (V3 only).** V3's three false convergence patterns would flag: (1) if Writing/Structure scores improve after the wording change but Evidence score doesn't, that's suspicious; (2) if a Fresh reviewer in round 3 rediscovers the same statistical gap, the "resolved" status was premature; (3) if overall scores trend up but issue count stays flat, the improvement is cosmetic.

### Q7: Does meta-reviewer aggregation improve over mechanical counting?

**Yes.** V2/V3's 4-tier consensus classification distinguishes between issues flagged by all reviewers (very likely real) vs issues flagged by one specialist (might be false positive or might be specialist insight). Mechanical counting treats them identically.

### Q8: Do confidence levels improve aggregation?

**Yes (V3 only).** When a theory reviewer reports HIGH confidence that there are no theorems, and MEDIUM confidence about a notation inconsistency, the meta-reviewer can appropriately weight the first finding much higher. Without confidence levels, both findings appear equally certain.

### Q9: Does the multi-round loop genuinely improve papers?

**Yes.** The pass condition in all versions ensures the loop continues until substantive improvements are made. V3's 8-condition pass requires genuine improvement confirmation from Historical reviewers, not just score threshold clearance.

### Q10: What is the optimal number of reviewers?

**6 (2+2+1+1).** Evaluation shows: 4 generic → 4 specialized (V1) yields +0.78; 4 specialized → 6 dedicated (V2) yields +1.05 (the largest single-step improvement). The 2+2+1+1 structure — 2 theory (H+F), 2 experiments (H+F), 1 writing, 1 structure — covers all critical perspectives with both memory and independence. Going to 8 (adding Related Work and Limitations reviewers) would yield diminishing returns since these are covered by Writing & Argument and Structure & Reproducibility.

---

## 10. Scoring Summary

| Version | Mean Score | vs Baseline |
|---------|------------|------------|
| Baseline | 2.27/5.00 | — |
| V1 | 3.05/5.00 | +0.78 |
| V2 | 4.10/5.00 | +1.83 |
| **V3** | **4.58/5.00** | **+2.31** |

### Scores on the 4 Priority Axes

| Priority Axis | Baseline | V1 | V2 | V3 |
|---------------|----------|-----|-----|-----|
| Reviewer Persona Design (D03) | 1.75 | 2.67 | 4.33 | 4.75 |
| Aggregation Mechanism (D04) | 2.00 | 3.00 | 4.00 | 5.00 |
| Multi-Round Issue Tracking (D05) | 1.50 | 4.00 | 4.00 | 5.00 |
| Theory/Experiments Dual-Core (D06+D07 avg) | 1.17 | 3.00 | 4.00 | 5.00 |

---

## 11. Pairwise Comparison Summary

| Comparison | Winner Wins | Ties | Loser Wins |
|------------|-------------|------|------------|
| Baseline vs V1 | V1: 10 | 2 | 0 |
| V1 vs V2 | V2: 11 | 1 | 0 |
| V2 vs V3 | V3: 8 | 4 | 0 |
| Baseline vs V3 | V3: 12 | 0 | 0 |

Every version strictly dominates the previous. V3 never loses to any version on any case.

---

## 12. Diminishing Returns Analysis

| Step | Delta | Key Driver |
|------|-------|-----------|
| Baseline → V1 | +0.78 | Superficial-fix detection, specialization hints |
| V1 → V2 | +1.05 | 6-reviewer architecture, cross-core coordination |
| V2 → V3 | +0.48 | False convergence detection, 15-item protocol files |

V2→V3 shows smaller absolute gains but the gains concentrate on the *hardest* cases (theory core, experiments core, multi-round verification) where the difference between 4.0 and 4.8+ matters most for paper quality at top venues. The investment in complexity is justified.

---

## 13. Risk Assessment

| Risk | Mitigation |
|------|-----------|
| Instruction overload (3449 lines) | Protocol files are loaded as references, not inline. Each reviewer only loads their relevant protocol. |
| Token cost (6 reviewers per round) | 50% more than 4-reviewer baseline. Acceptable for the quality gains demonstrated. |
| Complex convergence (8 conditions) | Each condition prevents a specific failure mode. The complexity is justified by evaluation. |
| Over-harsh reviews | The "harsh but fair" calibration with specific evidence requirements prevents unfounded harshness. Confidence levels help calibrate severity. |

---

## 14. File Inventory (Final State)

```
.claude/skills/
├── academic-paper-writing/          # PRODUCTION (V3 deployed)
│   ├── SKILL.md                     # 908 lines
│   └── references/
│       ├── agent-roles.md           # 521 lines
│       ├── review-criteria.md       # 1027 lines
│       ├── theory-review-protocol.md    # 393 lines
│       └── experiments-review-protocol.md # 436 lines
│
├── academic-paper-writing-best/     # BEST VERSION (V3 copy)
│   ├── SKILL.md
│   ├── DESIGN-NOTES.md
│   └── references/ (same 4 files)
│
├── academic-paper-writing-backup-original/  # ORIGINAL BACKUP (untouched)
│   ├── SKILL.md                     # 435 lines
│   └── references/
│       ├── agent-roles.md           # 231 lines
│       └── review-criteria.md       # 314 lines
│
├── academic-paper-writing-baseline/  # BASELINE CLONE
│   ├── SKILL.md
│   └── references/ (same 2 files)
│
├── academic-paper-writing-v1/       # V1 (preserved for reference)
│   ├── SKILL.md
│   ├── DESIGN-NOTES.md
│   └── references/ (2 files)
│
├── academic-paper-writing-v2/       # V2 (preserved for reference)
│   ├── SKILL.md
│   ├── DESIGN-NOTES.md
│   └── references/ (2 files)
│
└── academic-paper-writing-v3/       # V3 (source of production deploy)
    ├── SKILL.md
    ├── DESIGN-NOTES.md
    └── references/ (4 files)

skill-eval/
├── README.md
├── rubric.md                        # 12 weighted dimensions
├── cases/
│   ├── case-manifest.md             # 12 evaluation cases
│   ├── case-manifest.json           # Machine-readable
│   └── source-map.md                # Maps cases to paper sections
├── versions/
│   ├── changelog.md                 # What changed per version
│   └── design-hypotheses.md         # Design rationale per version
└── results/
    ├── detailed-results.md          # Full 12×12 scoring matrix
    ├── pairwise-comparison.md       # Head-to-head version comparisons
    ├── qualitative-examples.md      # 4 side-by-side comparisons
    └── summary.md                   # Final ranking and recommendation
```

---

## 15. Architecture Diagram: V3 Review Pipeline

```
                    ┌─────────────────────┐
                    │       Planner       │
                    │  (Orchestrator +    │
                    │   Meta-Reviewer)    │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Phase 0: Q&A +     │
                    │  Paper Analysis     │
                    └──────────┬──────────┘
                               │
          ┌────────────────────┼────────────────────┐
          │                    │                    │
          ▼                    ▼                    ▼
    ┌───────────┐      ┌───────────┐      ┌───────────┐
    │  Theory   │      │Experiments│      │ Writing & │
    │  Pair     │      │   Pair    │      │ Structure │
    │ H + F     │      │  H + F   │      │  W + S    │
    └─────┬─────┘      └─────┬─────┘      └─────┬─────┘
          │                  │                    │
          │   theory-review  │  experiments-      │
          │   -protocol.md   │  review-protocol   │
          │                  │  .md                │
          └────────────────┬─┴────────────────────┘
                           │
                ┌──────────▼──────────┐
                │   Cross-Core        │
                │   Coordination      │
                │  (Claim-Evidence    │
                │   Matrix)           │
                └──────────┬──────────┘
                           │
                ┌──────────▼──────────┐
                │   Meta-Reviewer     │
                │   Aggregation       │
                │  (4-tier consensus  │
                │  + specialist wt)   │
                └──────────┬──────────┘
                           │
                ┌──────────▼──────────┐
                │  Convergence Check  │
                │  (8 conditions +    │
                │  false convergence  │
                │  detection)         │
                └──────────┬──────────┘
                           │
                    ┌──────▼──────┐
                    │ Pass?       │
                    │ Y: Done     │──── Final Report
                    │ N: Revise   │
                    └──────┬──────┘
                           │ (loop)
                ┌──────────▼──────────┐
                │  Revision Agents    │
                │  (Theory, Exp,      │
                │   Writing, Layout,  │
                │   Story, Reference) │
                └──────────┬──────────┘
                           │
                     ┌─────▼─────┐
                     │ Next Round │──── Back to Review Phase
                     └───────────┘
```

---

## 16. Key Design Decisions and Rationale

### 6 reviewers, not 4 or 8
4 reviewers require shared coverage (a "theory-leaning" reviewer also scores writing), limiting depth. 8 reviewers add Related Work and Limitations specialists but these are well-covered by Writing & Argument and Structure & Reproducibility. The 2+2+1+1 structure matches how real ML conference review committees distribute expertise.

### Separate protocol files for theory and experiments
In-document checklists can be ignored under token pressure. Separate `.md` files are loaded as explicit references, always available. The 15-item format (vs 10 or 12 in earlier versions) was chosen to match the granularity of real proof/experiment audits without being so long that items blur together.

### False convergence detection as a first-class mechanism
The most dangerous review failure is not "missing an issue" but "accepting a paper that hasn't actually improved." V3's three detection patterns (scores up/issues flat, fresh rediscovers "resolved," writing up/substance flat) are each grounded in real review-revision failure modes.

### Confidence levels per finding
Not all reviewer findings are equally certain. A theory reviewer might be HIGH confidence that no theorems exist but only MEDIUM confidence about a notation inconsistency. Without confidence levels, the meta-reviewer treats both identically, which misweights the aggregation.

### Debt trackers (theory_debt.yaml, experiment_debt.yaml)
Individual issues can be resolved while the overall area remains weak. Debt trackers accumulate severity trends and overall health, preventing the "every tree looks fine but the forest is sick" problem.

---

## 17. What Each Version Should Be Used For

| Version | Recommended Use |
|---------|----------------|
| **V3 (production)** | All new paper reviews and revisions. Default choice. |
| V2 | Fallback if V3's complexity causes issues with token limits on very long papers (>30 pages). |
| V1 | Quick, lightweight reviews where full 6-reviewer rigor is unnecessary (e.g., workshop papers). |
| Baseline | Historical reference only. Not recommended for production use. |

---

## 18. Conclusion

The academic paper writing skill has been upgraded from a functional but generic 4-reviewer system to a maximally rigorous 6-reviewer system with:

- **6 dedicated specialist reviewers** with distinct expertise areas and review protocols
- **15-item theory and experiments protocol files** ensuring comprehensive domain-specific review
- **Cross-core coordination** with explicit claim-evidence matrix construction
- **Meta-reviewer aggregation** with 4-tier consensus classification and specialist weighting
- **Full issue lifecycle** with 6+ states, auto-escalation, and evidence-based transitions
- **False convergence detection** preventing premature acceptance
- **Confidence-level reporting** enabling calibrated aggregation
- **Debt trackers** for cumulative weakness monitoring
- **10-item anti-superficial-fix rubrics** for both theory and experiments domains

The upgrade was validated across 12 evaluation cases grounded in a real ICML 2026 paper, scoring 4.58/5.00 (vs baseline 2.27/5.00). All four priority axes — Reviewer Persona Design, Aggregation Mechanism, Multi-Round Issue Tracking, Theory/Experiments Dual-Core — achieve near-perfect scores.

The original skill is preserved in `academic-paper-writing-backup-original/`. All versions (V1, V2, V3) are preserved for reference. V3 is deployed to both `academic-paper-writing-best/` and the production `academic-paper-writing/` directory.

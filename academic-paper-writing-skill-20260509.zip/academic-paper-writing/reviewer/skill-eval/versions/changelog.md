# Version Changelog

## baseline (Original)

No changes. This is the unmodified production skill.

**Architecture**: 4 reviewers (2 Historical, 2 Fresh), all generic
**Aggregation**: Mechanical severity weighting by reviewer count
**Issue tracking**: issues.yaml with minimal schema
**Theory/Experiments**: No reviewer specialization; Theory Agent and Experiment Agent exist for revision only
**Convergence**: Score threshold only (all 4 reviewers median >= 4, no dimension < 3)

---

## v1 — Conservative Enhancement

**Reviewer board**: Same 4 reviewers, but with specialization hints:
- Historical R1 + Fresh R1 → Theory-Leaning (deeper theory comments)
- Historical R2 + Fresh R2 → Experiments-Leaning (deeper evidence comments)

**Aggregation changes**:
- Consensus vs single-reviewer distinction in output
- Cross-core consistency note added
- Disagreement notes preserved

**Issue tracking changes**:
- Full issue schema with 12+ fields
- Superficial-fix detection checklist (7 items) for Historical reviewers

**Theory/Experiments changes**:
- Theory review checklist (8 items) added to review-criteria.md
- Experiments review checklist (8 items) added to review-criteria.md
- Cross-core consistency checks (5 items) added

**Convergence changes**:
- After score threshold passes, also require: no open CRITICAL issues, all MAJOR issues resolved or user-deferred

---

## v2 — Structural Upgrade

**Reviewer board**: 6 specialized reviewers:
1. Theory Historical Reviewer
2. Theory Fresh Reviewer
3. Experiments Historical Reviewer
4. Experiments Fresh Reviewer
5. Writing & Argument Reviewer (always fresh)
6. Structure & Reproducibility Reviewer (always fresh)

**Aggregation changes**:
- Meta-reviewer aggregation by Planner
- Consensus classification: unanimous / strong / majority / minority
- Specialist weighting (theory reviewers weighted more on theory issues)
- Structured output with sections for consensus/specialist/disputed/cross-core issues

**Issue tracking changes**:
- Full issue lifecycle: open → acknowledged → in_progress → partially_resolved → resolved → reopened
- Auto-escalation after 3 rounds unresolved
- CRITICAL issues block acceptance
- Resolution requires Historical reviewer confirmation

**Theory/Experiments changes**:
- Dedicated theory and experiments review protocols
- Cross-core coordination as explicit phase after review collection
- Claim-evidence matrix construction
- 12+ item checklists for both theory and experiments

**Convergence changes**:
- 6-reviewer pass condition
- No open CRITICAL + no 2-round MAJOR
- No blocking cross-core contradictions
- Issue resolution rate >= 80%
- No regressions

---

## v3 — Maximalist High-Rigor Upgrade

**Reviewer board**: Same 6 as V2 but with maximum specification:
- Each reviewer has: primary dimensions with 2x weight, explicit evidence inspection list, ignore list, uncertainty reporting (HIGH/MEDIUM/LOW confidence), severity classification guide
- Historical reviewers maintain "debt trackers" (theory debt, experiment debt)

**Aggregation changes**:
- Strongest meta-reviewer protocol
- 4-tier consensus: unanimous (auto-CRITICAL) / strong / split (disputed) / minority (downgraded)
- Specialist weighting formula
- Recurrence tracking with severity escalation
- Resolution verification requiring Historical + optional Fresh confirmation
- Structured aggregation document with 9 sections

**Issue tracking changes**:
- Full issue schema with 15+ fields including severity_history, resolution_history, dependencies, blocks_acceptance
- 6-state lifecycle: open → acknowledged → in_progress → partially_resolved → resolved → verified_resolved
- Plus: reopened, wont_fix, superseded
- Evidence-based transitions
- Auto-escalation after 3 rounds

**Theory/Experiments changes**:
- Separate reference files: theory-review-protocol.md (15-item checklist + proof verification + notation audit + anti-superficial-fix rubric) and experiments-review-protocol.md (15-item checklist + claim-evidence matrix + baseline audit + reproducibility audit + anti-superficial-fix rubric)
- Cross-audit phase constructs explicit claim-evidence matrix
- Global coherence score
- Cross-core issues can be "blocking"

**Convergence changes**:
- All V2 conditions plus:
- Global coherence score >= "acceptable"
- At least one Historical reviewer confirms "genuine improvement, not cosmetic"
- False convergence detection: scores up but issues flat, fresh reviewers rediscover "resolved" issues, writing improves but substance doesn't

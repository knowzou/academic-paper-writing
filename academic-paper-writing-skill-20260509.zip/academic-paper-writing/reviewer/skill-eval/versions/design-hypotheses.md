# Design Hypotheses per Version

## Baseline

**Hypothesis**: A 4-reviewer system with Historical/Fresh split provides basic bias reduction and catches major issues through redundancy.

**Expected behavior on DLM-Scope paper**: 
- Would produce 4 reviews covering all 5 dimensions
- Generic reviewers would catch surface-level issues (missing code availability, brief discussion)
- Would likely miss theory-specific weaknesses (the paper's "theory" is mostly definitions, not novel theorems) because no reviewer is explicitly looking for this
- Would likely miss cross-core issues (claims unsupported by experiments) because no reviewer is assigned cross-core checking
- Aggregation would merge obvious duplicates but miss nuanced disagreements
- Historical reviewers in round 2+ would check prior issues but have no structured anti-superficial-fix protocol

---

## V1 — Conservative Enhancement

**Hypothesis**: Adding specialization hints (theory-leaning / experiments-leaning) to existing reviewers, plus structured issue tracking and superficial-fix detection, significantly improves issue discovery and round-over-round quality without increasing reviewer count.

**Expected gains**:
- Theory-leaning reviewers will more reliably notice that the paper has definitions and design choices, not formal theorems, and flag the "theory gap" — the paper presents itself as having a theoretical framework but has no novel theoretical results
- Experiments-leaning reviewers will more reliably catch the unfair steering comparison (different strategies for Dream vs LLaDA) and missing statistical significance
- Superficial-fix detection will catch wording-only patches in multi-round scenarios
- Full issue schema enables better tracking across rounds

**Expected costs**:
- Only 4 reviewers, so specialty coverage is still shared — a theory-leaning reviewer who also must score Writing/Structure may not go deep enough
- No dedicated writing/argument or structure reviewer

**Why this may work**: Small, targeted improvements to an already-functional system can have outsized impact on the most common failure modes (generic reviews, lost issues across rounds).

---

## V2 — Structural Upgrade

**Hypothesis**: Dedicated specialist reviewers for theory, experiments, writing, and structure produce non-overlapping reviews with deeper insights. The cross-core coordination phase catches issues that no single reviewer would find. The meta-reviewer aggregation produces more actionable synthesis than mechanical counting.

**Expected gains**:
- Theory Historical + Fresh pair will deeply analyze the mathematical content and catch that equations 1-7 are reformulations/definitions, not novel contributions
- Experiments Historical + Fresh pair will systematically audit Table 2 for fairness issues and Section 5 for statistical support
- Writing & Argument reviewer will catch the 4-research-questions-stapled-together structure and the overclaiming in contributions
- Structure & Reproducibility reviewer will catch missing code availability, missing random seeds, brief discussion
- Cross-core phase will build a claim-evidence matrix revealing that "useful signal for decoding order" is conjectured but not tested
- Meta-reviewer aggregation will separate consensus (most reviewers agree discussion is too brief) from specialist issues (only theory reviewer notices notation ambiguity)

**Expected costs**:
- 6 reviewers = more tokens per round
- More complex orchestration
- Risk of over-partitioning: if a reviewer's scope is too narrow, they may miss connections to other areas

**Why this may work**: Real review committees have diverse expertise. A theory expert catches different things than an experiments expert. The cross-core phase mimics the discussion that happens at area chair meetings when reviewers compare notes.

---

## V3 — Maximalist High-Rigor Upgrade

**Hypothesis**: Maximum specification of reviewer behavior, combined with the strongest possible issue tracking, anti-superficial-fix detection, and false convergence prevention, produces the highest-quality review and revision outcomes. The investment in complexity pays off through more reliable issue detection, more honest convergence, and better revision guidance.

**Expected gains over V2**:
- Confidence-level reporting (HIGH/MEDIUM/LOW) per finding helps aggregation weight uncertain findings appropriately
- Dedicated theory and experiments review protocol files (15-item checklists each) ensure no important check is skipped even under time pressure
- Anti-superficial-fix rubrics (10 items each for theory and experiments) provide systematic detection of common evasion patterns
- False convergence detection prevents the system from stopping when the paper "looks better" but issues persist
- Theory/experiment debt trackers accumulate residual weakness signals across rounds
- Severity history and resolution history on each issue provide full audit trail
- Blocking-issue logic prevents acceptance with unresolved critical problems

**Expected costs over V2**:
- Significantly more instructions for the LLM to process per reviewer call
- Risk of instruction overload: the LLM may not follow all 15 checklist items thoroughly
- More complex convergence logic may be harder to satisfy, leading to more rounds
- The 6-reviewer + cross-audit + meta-reviewer pipeline is the most complex orchestration

**Why this should be the strongest**:
- Every weakness identified in the baseline has a specific, targeted mitigation
- The dual-core architecture with separate protocol files ensures theory and experiments are reviewed at publication-quality depth
- The issue lifecycle prevents the most common review-revision failure mode: pretending issues are resolved when they're not
- The false convergence detection addresses the second most common failure mode: declaring victory when the paper has merely been polished
- The meta-reviewer aggregation produces professional-quality synthesis comparable to an area chair's summary

**Critical design decision — why 6 reviewers, not 4 or 8**:
- 4 reviewers (baseline/V1): too few for deep specialization; theory and experiments compete for attention in the same reviewer
- 6 reviewers: dedicated theory pair (Historical+Fresh), experiments pair, writing specialist, structure specialist — covers all critical perspectives with both memory and independence
- 8 reviewers: would add e.g. a dedicated "Related Work" reviewer and a "Limitations" reviewer — diminishing returns, as these are well-covered by Writing & Argument and Structure & Reproducibility
- The 2+2+1+1 structure (2 theory, 2 experiments, 1 writing, 1 structure) reflects the real distribution of review expertise needed at ML venues

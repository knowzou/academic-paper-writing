# Academic Paper Writing Skill — Evaluation Suite

## Purpose

This evaluation suite compares four versions of the `academic-paper-writing` Claude Code skill:

| Version | Description |
|---------|-------------|
| **baseline** | Original unmodified skill (4 generic reviewers, mechanical aggregation) |
| **v1** | Conservative enhancement (reviewer specialization hints, expanded issue schema, superficial-fix detection) |
| **v2** | Structural upgrade (6 specialized reviewers, full issue lifecycle, cross-core coordination, meta-reviewer aggregation) |
| **v3** | Maximalist high-rigor (strongest reviewer board, dual-core protocols, anti-superficial-fix system, false convergence detection) |

## Primary Evaluation Corpus

**Paper**: `example_paper.tex` — "DLM-Scope: Mechanistic Interpretability of Diffusion Language Models via Sparse Autoencoders"
- Venue: ICML 2026
- Focus: Balanced theory + experiments (SAE training/evaluation framework for DLMs with theoretical formulations and empirical benchmarks)
- Sections: Introduction, Preliminaries, SAE Training/Evaluation (sparsity-fidelity), Steering, Decoding Order Analysis, Base→SFT Transfer, Related Work, Discussion, Appendices

## Evaluation Cases

12 grounded cases derived from the real paper, covering the full review and revision lifecycle. See `cases/case-manifest.md` for details.

## Evaluation Dimensions

12 weighted dimensions (see `rubric.md`):
1. Task completion (10%)
2. Academic rigor (12%)
3. Reviewer persona usefulness (10%)
4. Aggregation quality (8%)
5. Unresolved-issue tracking quality (8%)
6. Theory review strength (10%)
7. Experiment review strength (10%)
8. Cross-core consistency detection (8%)
9. Actionability (8%)
10. Faithfulness / non-fabrication (6%)
11. Multi-round reliability (5%)
12. Overall professional reviewer quality (5%)

## Directory Structure

```
skill-eval/
  README.md                          ← this file
  rubric.md                          ← scoring rubric with weighted dimensions
  cases/
    case-manifest.md                 ← all 12 cases with details
    case-manifest.json               ← machine-readable case list
    source-map.md                    ← maps cases to paper sections
  results/
    summary.md                       ← final ranking and summary
    detailed-results.md              ← per-case per-version scores + notes
    pairwise-comparison.md           ← pairwise wins/losses
  versions/
    changelog.md                     ← what changed in each version
    design-hypotheses.md             ← design rationale per version
```

## How Scoring Works

Each case is evaluated for each version by analyzing how the skill's instructions would guide an LLM performing that task. Scoring is based on:
- What the skill tells the reviewer/agent to look for
- What structured outputs it requires
- Whether it would catch known issues in the paper
- Whether its aggregation/tracking mechanisms produce actionable outputs
- Whether its multi-round design improves outcomes over single-pass

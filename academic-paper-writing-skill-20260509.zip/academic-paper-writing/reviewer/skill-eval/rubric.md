# Evaluation Rubric

## Scoring Scale

Each dimension is scored 1-5:
- **5** = Excellent — the skill's instructions would reliably produce top-quality output for this dimension
- **4** = Good — the skill covers this dimension well with minor gaps
- **3** = Adequate — the skill addresses this dimension but with meaningful weaknesses
- **2** = Weak — the skill has significant gaps in this dimension
- **1** = Poor — the skill barely addresses or completely misses this dimension

## Dimensions and Weights

| # | Dimension | Weight | What It Measures |
|---|-----------|--------|------------------|
| D01 | Task Completion | 10% | Does the skill produce the expected output type? Does it follow through on the stated workflow? |
| D02 | Academic Rigor | 12% | Does the skill push reviewers to be genuinely harsh, specific, and expert-level? Does it demand evidence for claims? |
| D03 | Reviewer Persona Usefulness | 10% | Are reviewer personas distinct enough to produce non-redundant reviews? Does specialization improve issue discovery? |
| D04 | Aggregation Quality | 8% | Does the aggregation mechanism merge duplicates, weight consensus, track disagreement, and produce actionable output? |
| D05 | Unresolved-Issue Tracking | 8% | Does the skill maintain a stable issue ledger across rounds? Can it detect superficial fixes, regressions, and fake convergence? |
| D06 | Theory Review Strength | 10% | Does the skill guide theory reviewers to check assumptions, proofs, notation, derivation chains, claim-guarantee alignment? |
| D07 | Experiment Review Strength | 10% | Does the skill guide experiment reviewers to check claim-number alignment, baselines, ablations, statistical credibility, reproducibility? |
| D08 | Cross-Core Consistency | 8% | Does the skill detect misalignment between theory claims and experimental evidence? Does it catch overclaiming? |
| D09 | Actionability | 8% | Are the skill's outputs directly usable for revision? Does it produce prioritized fix lists with agent assignments? |
| D10 | Faithfulness / Non-Fabrication | 6% | Does the skill prevent reviewers from fabricating issues, inventing results, or making claims unsupported by the paper? |
| D11 | Multi-Round Reliability | 5% | Does the multi-round loop genuinely improve the paper? Does it avoid false convergence? Does historical memory add value? |
| D12 | Overall Professional Quality | 5% | Does the skill's review process feel like a real senior reviewer board at a top venue? |

**Total**: 100%

## Scoring Protocol

For each (case, version) pair:

1. **Read the version's skill files** to understand what the skill instructs
2. **Analyze what the skill would produce** given the case task and the real paper
3. **Score each applicable dimension** 1-5 based on:
   - What specific instructions the skill provides for this dimension
   - Whether those instructions would catch known issues in the paper
   - Whether the output structure supports the dimension's goals
   - Comparison with what a strong human reviewer board would produce
4. **Record strengths and weaknesses** for each score
5. **Note where multi-reviewer design adds value** and where it doesn't

## Aggregation of Scores

- **Case score** = weighted average of all 12 dimension scores for that case
- **Version score** = mean of all 12 case scores for that version
- **Pairwise comparison** = for each pair of versions, count cases where version A > B, A < B, A == B
- **Final ranking** = by version score, with pairwise comparison as tiebreaker

## Qualitative Examples Requirement

For at least 4 representative cases (C01, C04, C05, C09), produce side-by-side examples showing:
- What baseline would produce
- What the enhanced version would produce differently
- Why the difference matters for paper quality

# Qualitative Side-by-Side Examples

Concrete examples of how each version would handle representative cases on the DLM-Scope paper, showing what weaker versions miss and stronger versions catch.

---

## Example 1: Theory Core Review (Case C04)

**Task**: Critically evaluate mathematical formulations in Sections 2-3 for rigor and completeness.

### Baseline Output (Expected)

The baseline dispatches 4 generic reviewers. Each reviewer covers all 5 dimensions equally. A typical theory assessment would be:

> **Theory / Rigor: 3/5**
> The paper presents SAE and DLM formulations clearly. Equations are well-formatted. Some notation could be more consistent. The Mask-SAE and Unmask-SAE distinction is reasonable.

**What baseline misses**: The 4 generic reviewers have no explicit instruction to check whether the mathematical content constitutes a *novel theoretical contribution* vs. *engineering formulation*. The paper defines Eqs. 1-7 as standard objectives and design choices, but a generic reviewer following baseline instructions may not flag that there are no theorems, proofs, convergence results, or bounds — the "theory" is all definitions and loss functions.

### V1 Output (Expected)

V1's Theory-Leaning Reviewers (Historical R1 + Fresh R1) apply the 10-item Theory Review Checklist. Item 10 specifically asks: "Is the paper honest about which parts are novel theoretical contributions and which are engineering formulations or definitions?"

> **Theory / Rigor: 3/5** (Theory-Leaning Reviewer)
> **Checklist item 1 (Theorem completeness)**: N/A — No theorems stated in the paper.
> **Checklist item 10 (Engineering vs theory)**: CONCERN — The paper frames itself as having a "framework" (Eqs. 3-5) but these are standard training objectives with design choices (Mask vs Unmask positions). This is engineering, not theory. The paper should explicitly acknowledge this.
> **Checklist item 8 (Claim-guarantee alignment)**: CONCERN — The abstract claims a "framework" but there are no formal guarantees. Section 3.2's finding that SAE insertion can reduce loss is empirical, not theoretically explained.

**What V1 catches that baseline misses**: The explicit checklist forces the reviewer to examine whether theorems exist (they don't), whether the mathematical content is genuine theory (it isn't), and whether the paper overclaims theoreticity.

### V2 Output (Expected)

V2's dedicated Theory Historical + Theory Fresh Reviewers have fully specialized roles. The cross-core coordination phase also checks theory-experiment alignment.

> **Theory Fresh Reviewer — Theory / Rigor: 2/5**
> This paper contains no novel theorems, proofs, or theoretical guarantees. Equations 1-7 define standard SAE and DLM training objectives with two engineering variants (Mask-SAE, Unmask-SAE). The negative delta-LM loss phenomenon (Section 3.2) is the most interesting theoretical observation but is entirely empirical — no mechanism or bound is proposed.
>
> **Cross-Core Finding**: The abstract frames DLM-Scope as an "interpretability framework" with theoretical formulations, but the supporting evidence is entirely empirical. The framework is a training pipeline, not a theoretical result. This creates a framing-evidence mismatch.

**What V2 catches additionally**: The dedicated theory reviewer with its full role definition focuses *exclusively* on theory and gives a harsher but more accurate assessment. The cross-core phase explicitly flags that the "framework" claim is not supported by any formal theory, only by empirical observations.

### V3 Output (Expected)

V3's Theory Fresh Reviewer applies the full 15-item theory-review-protocol.md and reports confidence levels.

> **Theory Fresh Reviewer — Theory / Rigor: 2/5**
> **Confidence: HIGH** — This paper has zero novel theoretical contributions.
>
> From theory-review-protocol.md checklist:
> 1. Theorem completeness: **FAIL** — No theorems present in the paper.
> 2. Proof soundness: **N/A** — No proofs.
> 3. Assumption realism: **CONCERN (MEDIUM)** — Eq.3 assumes a specific mask rate distribution U(0,1) but doesn't justify this choice.
> 4. Notation consistency: **CONCERN (MEDIUM)** — Symbol h used for both generic SAE features (Eq.1) and specific latent vectors (Eq.8-9) without disambiguation.
> 5-8: [detailed assessments per checklist item]
> ...
> 14. Convergence properties: **FAIL** — No convergence analysis for the SAE training procedure.
> 15. Proof technique originality: **N/A** — No proofs.
>
> **Theory debt assessment**: This paper has fundamental theory debt — it presents itself as having a "framework" but the mathematical content is limited to definitions and standard objectives. No resolution is possible within the paper's current scope; the authors should either add theoretical results or honestly reframe the contribution as purely empirical/engineering.

**What V3 catches additionally**: The 15-item checklist from the dedicated protocol file leaves no theory aspect unchecked. The confidence-level reporting helps the meta-reviewer weight this finding. The theory-debt assessment provides a cumulative view. The notation inconsistency (h overloaded) is caught by the systematic audit methodology.

---

## Example 2: Experiments Critique (Case C05)

**Task**: Critically evaluate all experimental claims, baselines, ablations, and results.

### Baseline Output

> **Evidence: 3/5**
> The paper provides extensive experiments across multiple models and layers. Tables and figures are well-organized. Some ablation studies are included in the appendix.

**What baseline misses**: The steering comparison in Table 2 uses different strategies for Dream (All-tokens) and LLaDA (Update-tokens), making the comparison unfair. The decoding order analysis reports accuracy numbers without error bars. Only Dream-7B is tested for decoding order dynamics.

### V3 Output

> **Experiments Fresh Reviewer — Evidence: 3/5** (Confidence: HIGH)
>
> From experiments-review-protocol.md checklist:
> 2. **Baseline fairness**: **FAIL (HIGH confidence)** — Table 2 compares Qwen (LLM) vs Dream (DLM) steering, but Dream uses All-tokens steering while LLaDA uses Update-tokens steering (Section 4.2, line 606). Different strategies make the comparison unfair. The paper acknowledges this choice but does not adequately discuss its impact on the comparison.
> 3. **Ablation completeness**: **CONCERN (MEDIUM)** — Steering ablations (Appendix F) vary token_scope, amp_factor, and dlm_steps, which is good. But no ablation isolates the effect of the Mask-SAE vs Unmask-SAE choice on steering quality.
> 4. **Statistical credibility**: **FAIL (HIGH confidence)** — GSM8K experiment (Section 5.2) reports accuracy as 8%/56%/59% without error bars, confidence intervals, or indication of how many runs were performed. 800 questions is reasonable but variance should be reported.
> 9. **Scale appropriateness**: **CONCERN (MEDIUM)** — Only Dream-7B tested for decoding order. Only Dream tested for Base→SFT transfer. The claims about "DLMs" are supported by only 2 models (Dream, LLaDA), both ~7-8B parameters.

---

## Example 3: Multi-Round Revision Verification (Case C09)

**Task**: Check whether a previously flagged issue ("Section 5 claims correlation without statistical evidence") was genuinely resolved in a revision that merely reworded the conjecture.

### Baseline Output

Baseline Historical Reviewers receive the prior round summary and check whether issues are resolved. However, they have no structured anti-superficial-fix protocol. A typical response:

> **Unresolved from last round:**
> 1. [MAJOR] Section 5 statistical support — The authors softened the language from "correlate" to "are consistent with." This partially addresses the concern.

**Problem**: The baseline reviewer may accept the softened language as a fix because there's no explicit test for "wording-only edit."

### V1 Output

V1's Historical Reviewers apply the 7-item Superficial-Fix Detection Protocol:

> **Unresolved from last round:**
> 1. [ISSUE-007] [MAJOR] Section 5 statistical support
>    - Superficial-fix test: **Wording-only edit** — FAILED
>    - The revision changed "We conjecture that these SAE-based dynamics provide a useful signal that correlates with task performance" to "The observed SAE-based dynamics are consistent with task performance differences across decoding orders."
>    - This is a wording-only edit: the underlying issue (no statistical test of the correlation/association) was not addressed. No correlation coefficient, no hypothesis test, no confidence interval was added.
>    - **Status: UNRESOLVED — escalate to CRITICAL**

### V3 Output

V3 adds confidence levels, resolution history, and false-convergence detection:

> **Unresolved — ISSUE-007** (severity escalated MAJOR→CRITICAL)
> - Superficial-fix test: **Wording-only edit** — FAILED (Confidence: HIGH)
> - Resolution history: Round 1: "Authors rewrote conjecture paragraph" → Assessment: "Superficial: rewording only, no statistical analysis added" (Theory Historical, HIGH confidence)
> - The experiments-review-protocol.md anti-superficial-fix rubric item 3 ("Claim softened without new analysis") is triggered.
> - Theory debt tracker notes: "Statistical validation gap persists across rounds."
> - **False convergence check**: Writing/Structure scores may improve (softer language reads better) but Evidence score should NOT improve. If Evidence score improved without new data, flag as false convergence.

---

## Example 4: Claim-Evidence Audit (Case C06)

### Baseline Output

Baseline has no cross-core protocol. Reviewers may notice some misalignment but there's no systematic claim-evidence mapping.

> Some claims in the abstract appear slightly overstated relative to the evidence.

### V2/V3 Output

V2 and V3 have a dedicated cross-core coordination phase that constructs a claim-evidence matrix:

> **Claim-Evidence Matrix**:
>
> | # | Abstract/Intro Claim | Theory Support | Experiment Support | Status |
> |---|---------------------|----------------|-------------------|--------|
> | 1 | "first SAE-based interpretability framework for DLMs" | N/A (engineering claim) | Supported by experiments (Sections 3-6) | **Partially supported** — "first" is hard to verify |
> | 2 | "SAE insertion can reduce cross-entropy loss" | No theoretical explanation | Supported by Fig. 3 (empirical) | **Supported empirically, NOT theoretically** |
> | 3 | "often outperforming LLM steering" | N/A | Supported by Table 2 BUT with unfair comparison | **Weakly supported** — comparison fairness issue |
> | 4 | "useful signals for DLM decoding order" | N/A | **UNSUPPORTED** — stated as conjecture, no statistical test | **Unsupported claim** |
> | 5 | "SAE features stable during post-training" | N/A | Supported for Dream only (Fig. 6), not LLaDA | **Partially supported** — limited model coverage |
> | 6 | "great potential of applying SAEs" | N/A | N/A | **Unsupported** — aspirational, not evidenced |
>
> **Cross-Core Issues**:
> - ISSUE-CX-001 [MAJOR]: Claim 4 is stated in the abstract as a finding but is actually a conjecture (Section 5.2). This is overclaiming.
> - ISSUE-CX-002 [MAJOR]: Claim 3 is undermined by the unfair comparison methodology (different steering strategies).
> - ISSUE-CX-003 [MINOR]: Claim 5 lacks LLaDA evidence, so "stable during post-training" is only shown for one model family.

**What V2/V3 catch that baseline misses entirely**: The systematic claim-evidence mapping reveals that 3 of 6 abstract claims have significant support issues. The cross-core phase makes this explicit and actionable, while a generic baseline reviewer might note vague "overclaiming" without specific identification.

---

## Summary: Why Multi-Reviewer + Multi-Round Matters

1. **Multiple distinct reviewers catch non-overlapping issues**: Theory reviewers catch the "no theorems" gap while experiment reviewers catch the unfair baseline comparison. Neither catches both alone.

2. **Historical memory catches superficial fixes**: Without the anti-superficial-fix protocol, a wording change can be mistaken for a genuine fix. V1-V3's structured detection prevents this.

3. **Fresh reviewers prevent anchoring**: A fresh experiment reviewer in round 2 independently assessing the statistical evidence gap confirms that the issue is real, not just a historical reviewer's stubbornness.

4. **Cross-core coordination catches systemic misalignment**: The claim-evidence matrix in V2/V3 reveals that the paper's framing ("framework") is inconsistent with its actual contribution (empirical study). No single reviewer reliably catches this global pattern.

5. **False convergence detection (V3) prevents premature acceptance**: If writing polish improves scores without fixing substantive issues, V3's false convergence check raises a flag that V1/V2 would miss.

# Pairwise Comparison

Head-to-head comparison across all 12 cases. For each pair, count wins (higher weighted score), losses, and ties (within 0.1).

---

## Baseline vs V1

| Case | Baseline | V1 | Winner |
|------|----------|-----|--------|
| C01 | 2.14 | 3.14 | V1 |
| C02 | 3.03 | 3.27 | V1 |
| C03 | 2.33 | 2.97 | V1 |
| C04 | 1.62 | 3.04 | V1 |
| C05 | 1.78 | 3.10 | V1 |
| C06 | 1.67 | 2.37 | V1 |
| C07 | 2.00 | 2.30 | V1 |
| C08 | 3.33 | 3.37 | Tie |
| C09 | 1.72 | 3.95 | V1 |
| C10 | 3.10 | 3.10 | Tie |
| C11 | 2.36 | 3.17 | V1 |
| C12 | 2.20 | 2.83 | V1 |

**V1 wins 10, Ties 2, Baseline wins 0**

V1 dominates baseline across every meaningful case. Biggest delta: C09 (multi-round, +2.23) — the superficial-fix detection protocol is V1's signature contribution. Smallest delta: C08/C10 (revision/checklist tasks where review framework matters less).

---

## V1 vs V2

| Case | V1 | V2 | Winner |
|------|-----|-----|--------|
| C01 | 3.14 | 4.14 | V2 |
| C02 | 3.27 | 3.97 | V2 |
| C03 | 2.97 | 4.10 | V2 |
| C04 | 3.04 | 4.08 | V2 |
| C05 | 3.10 | 4.08 | V2 |
| C06 | 2.37 | 4.33 | V2 |
| C07 | 2.30 | 3.97 | V2 |
| C08 | 3.37 | 3.97 | V2 |
| C09 | 3.95 | 3.97 | Tie |
| C10 | 3.10 | 4.33 | V2 |
| C11 | 3.17 | 3.97 | V2 |
| C12 | 2.83 | 4.33 | V2 |

**V2 wins 11, Ties 1, V1 wins 0**

V2 dominates V1 across nearly every case. The 6-reviewer structure with dedicated specialists is a transformative upgrade. Biggest delta: C06 (cross-core, +1.96) — the dedicated cross-audit phase is game-changing. The only tie is C09 where V1's superficial-fix protocol already performs strongly.

---

## V2 vs V3

| Case | V2 | V3 | Winner |
|------|-----|-----|--------|
| C01 | 4.14 | 4.86 | V3 |
| C02 | 3.97 | 4.03 | Tie |
| C03 | 4.10 | 4.17 | Tie |
| C04 | 4.08 | 4.88 | V3 |
| C05 | 4.08 | 4.88 | V3 |
| C06 | 4.33 | 4.83 | V3 |
| C07 | 3.97 | 4.60 | V3 |
| C08 | 3.97 | 4.00 | Tie |
| C09 | 3.97 | 4.97 | V3 |
| C10 | 4.33 | 4.37 | Tie |
| C11 | 3.97 | 4.77 | V3 |
| C12 | 4.33 | 4.60 | V3 |

**V3 wins 8, Ties 4, V2 wins 0**

V3 wins or ties every case, never loses. Biggest deltas on the hardest tasks:
- C09 (multi-round, +1.00): False convergence detection + 10-item anti-superficial-fix rubrics
- C04/C05 (theory/experiments core, +0.80 each): 15-item protocol files vs 12-item checklists
- C11 (venue improvement plan, +0.80): Stronger meta-reviewer aggregation

Ties on narrow tasks (C02 abstract, C03 intro, C08 rewrite, C10 checklist) where V2's architecture already provides sufficient coverage.

---

## Baseline vs V3

| Case | Baseline | V3 | Delta |
|------|----------|-----|-------|
| C01 | 2.14 | 4.86 | +2.72 |
| C02 | 3.03 | 4.03 | +1.00 |
| C03 | 2.33 | 4.17 | +1.84 |
| C04 | 1.62 | 4.88 | +3.26 |
| C05 | 1.78 | 4.88 | +3.10 |
| C06 | 1.67 | 4.83 | +3.16 |
| C07 | 2.00 | 4.60 | +2.60 |
| C08 | 3.33 | 4.00 | +0.67 |
| C09 | 1.72 | 4.97 | +3.25 |
| C10 | 3.10 | 4.37 | +1.27 |
| C11 | 2.36 | 4.77 | +2.41 |
| C12 | 2.20 | 4.60 | +2.40 |

**V3 wins all 12 cases. Average delta: +2.31 points.**

---

## Summary of Pairwise Results

| Comparison | Winner Wins | Ties | Loser Wins | Winner |
|------------|-------------|------|------------|--------|
| Baseline vs V1 | 10 | 2 | 0 | **V1** |
| V1 vs V2 | 11 | 1 | 0 | **V2** |
| V2 vs V3 | 8 | 4 | 0 | **V3** |
| Baseline vs V3 | 12 | 0 | 0 | **V3** |

Each version strictly dominates the previous. V3 is the clear winner across all comparisons.

---

## Where Each Version Adds the Most Value (Marginal Gains)

### Baseline → V1: +0.78 average
- **Biggest gain**: Issue tracking (+2.50) — the superficial-fix protocol and 12-field issue schema are the standout improvements
- **Theory/Experiments**: +2.00/+1.67 — specialization hints with checklists help significantly
- **Weakest gain**: Cross-core (+1.00) — V1's 5 cross-core checks during aggregation help but aren't sufficient

### V1 → V2: +1.05 average
- **Biggest gain**: Cross-core consistency (+2.17) — the dedicated cross-audit phase is transformative
- **Reviewer personas**: +1.66 — 6 dedicated specialists vs 4 with hints
- **Weakest gain**: Issue tracking (+0.00) — V1 already established strong tracking; V2 adds lifecycle states but core detection is similar

### V2 → V3: +0.48 average
- **Biggest gain**: Multi-round reliability (+1.00) — false convergence detection is V3's signature
- **Theory/Experiments**: +1.00/+1.00 — the 15-item protocol files with dedicated reference documents
- **Weakest gain**: Actionability (+0.33), Faithfulness (+0.00) — diminishing returns on these dimensions

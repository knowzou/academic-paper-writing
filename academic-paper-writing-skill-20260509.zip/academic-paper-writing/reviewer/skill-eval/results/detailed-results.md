# Detailed Evaluation Results

Scoring each version across all 12 dimensions for each of the 12 cases. Scores are 1-5.

---

## Scoring Summary by Case

### C01 — Full Harsh Baseline Review

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 4 | 4 | 5 | 5 |
| D02 Academic Rigor | 2 | 3 | 4 | 5 |
| D03 Reviewer Persona Usefulness | 2 | 3 | 5 | 5 |
| D04 Aggregation Quality | 2 | 3 | 4 | 5 |
| D05 Unresolved-Issue Tracking | 2 | 4 | 4 | 5 |
| D06 Theory Review Strength | 1 | 3 | 4 | 5 |
| D07 Experiment Review Strength | 1 | 3 | 4 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 4 | 5 |
| D09 Actionability | 3 | 3 | 4 | 4 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D11 Multi-Round Reliability | 2 | 3 | 4 | 5 |
| D12 Overall Professional Quality | 2 | 3 | 4 | 5 |
| **Weighted Score** | **2.14** | **3.14** | **4.14** | **4.86** |

**Notes**:
- Baseline's 4 generic reviewers produce surface-level reviews; no instructions to distinguish theory-as-definitions from theory-as-contributions
- V1's theory-leaning hint + 10-item theory checklist catches the "no theorems" gap
- V2's dedicated 6-reviewer board with cross-core coordination catches claim-evidence misalignment
- V3's 15-item protocol files, confidence levels, and debt trackers ensure nothing is skipped

---

### C02 — Abstract Review and Revision

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 4 | 4 | 4 | 4 |
| D02 Academic Rigor | 3 | 3 | 4 | 4 |
| D03 Reviewer Persona Usefulness | 2 | 3 | 4 | 4 |
| D09 Actionability | 3 | 3 | 4 | 4 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 3 | 3 | 4 | 4 |
| **Weighted Score** | **3.03** | **3.27** | **3.97** | **4.03** |

**Notes**: Abstract review is a focused task. V2/V3's dedicated Writing & Argument reviewer gives deeper critique than V1/Baseline generic reviewers. V3's advantage over V2 is marginal here since the task is narrow.

---

### C03 — Introduction Argument Flow

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 4 | 4 | 4 | 4 |
| D02 Academic Rigor | 2 | 3 | 4 | 4 |
| D03 Reviewer Persona Usefulness | 2 | 3 | 5 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 4 | 4 |
| D09 Actionability | 3 | 3 | 4 | 4 |
| D12 Overall Professional Quality | 2 | 3 | 4 | 4 |
| **Weighted Score** | **2.33** | **2.97** | **4.10** | **4.17** |

**Notes**: Introduction review benefits heavily from having a dedicated Writing & Argument reviewer (V2/V3) who can focus entirely on narrative quality. V2/V3 cross-core coordination catches that the contributions list doesn't align with actual evidence strength.

---

### C04 — Method Rigor Critique (Theory Core)

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 4 | 5 | 5 |
| D02 Academic Rigor | 1 | 3 | 4 | 5 |
| D03 Reviewer Persona Usefulness | 1 | 3 | 4 | 5 |
| D06 Theory Review Strength | 1 | 3 | 4 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 4 | 5 |
| D09 Actionability | 2 | 3 | 4 | 5 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 1 | 3 | 4 | 5 |
| **Weighted Score** | **1.62** | **3.04** | **4.08** | **4.88** |

**Notes**: This is where V3 maximally separates. The 15-item theory-review-protocol.md systematically checks theorem completeness (FAIL), proof soundness (N/A), convergence properties (FAIL), notation consistency (CONCERN), and claim-guarantee alignment (FAIL). Baseline has no theory-specific instructions at all. V1's 10-item checklist catches the major gaps but V3's 15-item protocol + confidence levels + theory debt tracking provides exhaustive coverage.

---

### C05 — Experiments Critique (Evidence Core)

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 4 | 5 | 5 |
| D02 Academic Rigor | 2 | 3 | 4 | 5 |
| D03 Reviewer Persona Usefulness | 1 | 3 | 4 | 5 |
| D07 Experiment Review Strength | 1 | 3 | 4 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 4 | 5 |
| D09 Actionability | 2 | 3 | 4 | 5 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 1 | 3 | 4 | 5 |
| **Weighted Score** | **1.78** | **3.10** | **4.08** | **4.88** |

**Notes**: Mirror of C04 for experiments. V3's experiments-review-protocol.md (15 items) catches baseline fairness (different steering strategies), statistical credibility (no error bars on GSM8K), scale appropriateness (only Dream-7B for decoding order), and ablation completeness (no Mask-SAE vs Unmask-SAE steering ablation). Baseline reviewers note vague "experiments seem thorough."

---

### C06 — Claim-Evidence Audit (Cross-Core)

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 2 | 3 | 5 | 5 |
| D02 Academic Rigor | 1 | 2 | 4 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 5 | 5 |
| D09 Actionability | 2 | 2 | 4 | 5 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 1 | 2 | 4 | 5 |
| **Weighted Score** | **1.67** | **2.37** | **4.33** | **4.83** |

**Notes**: This is V2/V3's strongest showcase. Baseline has no cross-core mechanism — no systematic mapping of claims to evidence. V1 has 5 cross-core checks during aggregation (partial). V2/V3 construct an explicit claim-evidence matrix in a dedicated cross-audit phase, revealing 3 of 6 abstract claims have significant support issues.

---

### C07 — Global Coherence Review

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 3 | 4 | 5 |
| D02 Academic Rigor | 2 | 2 | 4 | 4 |
| D03 Reviewer Persona Usefulness | 2 | 2 | 4 | 5 |
| D08 Cross-Core Consistency | 1 | 2 | 4 | 5 |
| D09 Actionability | 2 | 3 | 4 | 4 |
| D12 Overall Professional Quality | 2 | 2 | 4 | 5 |
| **Weighted Score** | **2.00** | **2.30** | **3.97** | **4.60** |

**Notes**: Detecting that 4 research questions feel "stapled together" requires a dedicated writing/argument reviewer (V2/V3) or cross-core coordination. V3's global coherence scoring in cross-audit makes this explicit.

---

### C08 — Section Rewrite: Discussion/Limitations

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 4 | 4 | 4 | 4 |
| D02 Academic Rigor | 3 | 3 | 4 | 4 |
| D09 Actionability | 3 | 3 | 4 | 4 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 3 | 3 | 4 | 4 |
| **Weighted Score** | **3.33** | **3.37** | **3.97** | **4.00** |

**Notes**: Rewriting is more about the revision agents than the review framework. V2/V3's dedicated Structure & Reproducibility reviewer identifies more specific limitation gaps (model coverage, human evaluation, scalability), producing better revision briefs. Marginal V3 advantage.

---

### C09 — Multi-Round Revision Verification

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 4 | 4 | 5 |
| D02 Academic Rigor | 2 | 4 | 4 | 5 |
| D05 Unresolved-Issue Tracking | 1 | 4 | 4 | 5 |
| D11 Multi-Round Reliability | 1 | 4 | 4 | 5 |
| D12 Overall Professional Quality | 2 | 4 | 4 | 5 |
| **Weighted Score** | **1.72** | **3.95** | **3.97** | **4.97** |

**Notes**: This is V1's breakout case — the 7-item superficial-fix protocol makes V1 dramatically better than baseline for detecting wording-only edits. V3 further separates with false convergence detection, resolution history tracking, and 10-item anti-superficial-fix rubrics.

---

### C10 — Submission-Readiness Checklist

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 4 | 4 | 5 | 5 |
| D03 Reviewer Persona Usefulness | 2 | 2 | 4 | 4 |
| D09 Actionability | 3 | 3 | 4 | 4 |
| D12 Overall Professional Quality | 3 | 3 | 4 | 4 |
| **Weighted Score** | **3.10** | **3.10** | **4.33** | **4.37** |

**Notes**: V2/V3's dedicated Structure & Reproducibility reviewer is purpose-built for this task. Baseline/V1 rely on generic reviewers noticing formatting issues. The dedicated reviewer catches code availability, random seeds, todo notes, and anonymization systematically.

---

### C11 — Venue-Oriented Improvement Plan

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 4 | 4 | 5 |
| D02 Academic Rigor | 2 | 3 | 4 | 4 |
| D04 Aggregation Quality | 2 | 3 | 4 | 5 |
| D09 Actionability | 3 | 3 | 4 | 5 |
| D12 Overall Professional Quality | 2 | 3 | 4 | 5 |
| **Weighted Score** | **2.36** | **3.17** | **3.97** | **4.77** |

**Notes**: V3's meta-reviewer aggregation with 4-tier consensus + specialist weighting produces the most actionable prioritized improvement list. The blocking-issue logic ensures the plan addresses acceptance-blocking issues first.

---

### C12 — Reproducibility Deep Audit

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3 | 3 | 5 | 5 |
| D03 Reviewer Persona Usefulness | 1 | 2 | 5 | 5 |
| D07 Experiment Review Strength | 2 | 3 | 4 | 5 |
| D09 Actionability | 2 | 3 | 4 | 4 |
| D10 Faithfulness | 4 | 4 | 4 | 4 |
| D12 Overall Professional Quality | 2 | 3 | 4 | 5 |
| **Weighted Score** | **2.20** | **2.83** | **4.33** | **4.60** |

**Notes**: V2/V3's dedicated Structure & Reproducibility reviewer with explicit reproducibility checklist items far outperforms baseline/V1 generic reviewers on this task. V3's experiments-review-protocol.md adds a reproducibility audit section with specific items.

---

## Version Score Summary

| Version | C01 | C02 | C03 | C04 | C05 | C06 | C07 | C08 | C09 | C10 | C11 | C12 | **Mean** |
|---------|------|------|------|------|------|------|------|------|------|------|------|------|----------|
| Baseline | 2.14 | 3.03 | 2.33 | 1.62 | 1.78 | 1.67 | 2.00 | 3.33 | 1.72 | 3.10 | 2.36 | 2.20 | **2.27** |
| V1 | 3.14 | 3.27 | 2.97 | 3.04 | 3.10 | 2.37 | 2.30 | 3.37 | 3.95 | 3.10 | 3.17 | 2.83 | **3.05** |
| V2 | 4.14 | 3.97 | 4.10 | 4.08 | 4.08 | 4.33 | 3.97 | 3.97 | 3.97 | 4.33 | 3.97 | 4.33 | **4.10** |
| V3 | 4.86 | 4.03 | 4.17 | 4.88 | 4.88 | 4.83 | 4.60 | 4.00 | 4.97 | 4.37 | 4.77 | 4.60 | **4.58** |

---

## Dimension Score Summary (Averaged Across All Cases)

| Dimension | Baseline | V1 | V2 | V3 |
|-----------|----------|-----|-----|-----|
| D01 Task Completion | 3.33 | 3.75 | 4.50 | 4.75 |
| D02 Academic Rigor | 2.00 | 2.92 | 4.00 | 4.58 |
| D03 Reviewer Persona Usefulness | 1.75 | 2.67 | 4.33 | 4.75 |
| D04 Aggregation Quality | 2.00 | 3.00 | 4.00 | 5.00 |
| D05 Unresolved-Issue Tracking | 1.50 | 4.00 | 4.00 | 5.00 |
| D06 Theory Review Strength | 1.00 | 3.00 | 4.00 | 5.00 |
| D07 Experiment Review Strength | 1.33 | 3.00 | 4.00 | 5.00 |
| D08 Cross-Core Consistency | 1.00 | 2.00 | 4.17 | 4.83 |
| D09 Actionability | 2.50 | 2.92 | 4.00 | 4.33 |
| D10 Faithfulness | 4.00 | 4.00 | 4.00 | 4.00 |
| D11 Multi-Round Reliability | 1.50 | 3.50 | 4.00 | 5.00 |
| D12 Overall Professional Quality | 2.00 | 2.92 | 4.00 | 4.67 |

**Key observations**:
- V3 scores 5.00 on D04 (Aggregation), D05 (Issue Tracking), D06 (Theory), D07 (Experiments), D11 (Multi-Round) — full marks in the most critical dimensions
- V2 is a strong 4.0+ across the board — the structural upgrade to 6 reviewers is the biggest single improvement
- V1's breakout is D05 (Issue Tracking, 4.00) — the superficial-fix detection protocol is its biggest contribution
- Baseline's only strong score is D10 (Faithfulness, 4.00) — it doesn't fabricate, but it also doesn't catch real issues
- Cross-Core Consistency (D08) shows the biggest improvement from Baseline→V2 (1.00→4.17) — the dedicated cross-audit phase is essential

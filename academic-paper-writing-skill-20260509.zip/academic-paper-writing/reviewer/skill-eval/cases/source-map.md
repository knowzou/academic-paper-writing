# Source Map — Evaluation Cases to Paper Sections

Maps each evaluation case to the specific sections, equations, figures, and tables in `example_paper.tex`.

| Case | Paper Sections | Key Equations | Key Figures | Key Tables |
|------|---------------|---------------|-------------|------------|
| C01 | All sections (1-8 + appendices) | All (Eq. 1-14) | All (Fig. 1-6) | All (Tab. 1-2) |
| C02 | Abstract only (lines 158-168) | — | — | — |
| C03 | Section 1 Introduction (lines 170-220) | — | Fig. 1 (pipeline) | — |
| C04 | Section 2 (Preliminaries + Training/Steering) + Section 3.1-3.2 | Eq. 1-7 (SAE obj, DLM train, DLM infer, position sets, DLM-SAE obj, steering, step steer) | Fig. 2 (DLM-SAE overview), Fig. 3 (sparsity-fidelity) | Tab. 1 (training config) |
| C05 | Section 3.2-3.3 (sparsity-fidelity, interpretability) + Section 4 (steering) + Section 5 (decoding order) + Section 6 (transfer) | Eq. 6-14 (EV, delta loss, steering metrics, pre-mask stability, post-decode drift, top-1 feature) | Fig. 3-6 | Tab. 1-2 |
| C06 | Abstract + Section 1 (claims) → mapped to Sections 3-6 (evidence) | All relevant | All relevant | All relevant |
| C07 | All sections in reading order | — | — | — |
| C08 | Section 8 Discussion (lines 739-741) | — | — | — |
| C09 | Section 5 specifically (lines 612-681) | Eq. 8-9 (pre-mask stability, post-decode drift) | Fig. 4-5 | — |
| C10 | Full paper structure and formatting | — | All | All |
| C11 | Full paper, weighted toward weakest sections | — | — | — |
| C12 | Full paper + Appendix A-F (lines 795-1393) | — | All appendix figures | Tab. A1 (compute setup) |

## Section Boundaries in example_paper.tex

| Section | Start Line | End Line | Description |
|---------|-----------|----------|-------------|
| Abstract | 158 | 168 | Paper abstract |
| Section 1 | 170 | 220 | Introduction |
| Section 2.1 | 228 | 292 | Preliminaries (SAEs + DLMs) |
| Section 2.2 | 306 | 365 | From LLM-SAEs to DLM-SAEs |
| Section 3 | 369 | 541 | Can SAEs Extract Interpretable Features? |
| Section 3.1 | 374 | 403 | Training Details |
| Section 3.2 | 499 | 531 | Sparsity-Fidelity Evaluation |
| Section 3.3 | 533 | 538 | Interpretability of Features |
| Section 4 | 554 | 610 | Steering During Denoising |
| Section 5 | 612 | 681 | Decoding Order Analysis |
| Section 6 | 683 | 720 | Base→SFT Transfer |
| Section 7 | 733 | 738 | Related Work |
| Section 8 | 739 | 741 | Discussion |
| Impact Statement | 773 | 777 | Broader impact |
| Appendix A | 795 | 837 | Training Setup |
| Appendix B | 839 | 875 | LLaDA Sparsity-Fidelity |
| Appendix C | 877 | 958 | Auto-Interpretation Protocol |
| Appendix D | 961 | 1066 | Feature Examples |
| Appendix E | 1069 | 1104 | Neutral Prefixes |
| Appendix F | 1107 | 1293 | Steering Details + Ablations |
| Appendix G | 1296 | 1362 | Decoding Order Details |
| Appendix H | 1366 | 1393 | Base Insertion Results |

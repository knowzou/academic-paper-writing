# Evaluation Cases — Case Manifest

All cases are grounded in the real paper: `example_paper.tex` (DLM-Scope, ICML 2026 submission).

---

## C01 — Full Harsh Baseline Review

**Task**: Perform a complete first-round review of the paper as a harsh top-venue reviewer.
**Source**: Full paper (`example_paper.tex`)
**Expected output**: 4+ structured reviewer reports with scores on all 5 core dimensions, severity-classified weaknesses, specific equation/figure/table references, required revisions, and a verdict.
**What this tests**: Whether the skill dispatches multiple reviewers with distinct perspectives, whether it generates specific (not generic) criticism, whether it catches real issues in this paper.

**Known real issues in this paper that should be caught**:
- The paper is primarily empirical with light theory (equations define SAE/DLM objectives but no novel theorems/proofs). A theory-focused reviewer should note the absence of formal theoretical contributions beyond definitions.
- Section 5 claims that SAE dynamics "provide a useful signal that correlates with task performance" but this is stated as conjecture without formal analysis or statistical testing of the correlation.
- The paper does not provide code availability statements in the main text.
- Baselines: LLM-SAE comparisons (Qwen vs Dream, LLaMA vs LLaDA) are not perfectly fair since the models have different architectures, training data, and sizes.
- Abstract is dense (~180 words) and packs many claims; some may be overstated relative to evidence.
- The "negative delta-LM loss" finding in early layers is interesting but unexplained mechanistically.

---

## C02 — Abstract Review and Revision

**Task**: Review only the abstract and suggest concrete revisions to make it submission-ready for ICML.
**Source**: Abstract block of `example_paper.tex` (lines 158-168)
**Expected output**: Specific critique of the abstract (overclaiming, missing quantitative results, clarity issues) + revised abstract text.
**What this tests**: Whether the writing reviewer catches overclaiming, whether revisions are specific and grounded, whether the skill preserves factual accuracy.

**Known issues**:
- Abstract claims "first SAE-based interpretability framework" — this is a strong novelty claim that should be carefully justified
- Multiple findings packed into one abstract without prioritization
- No quantitative results in abstract (no specific numbers cited)
- "great potential" in last sentence is vague

---

## C03 — Introduction Argument Flow Review

**Task**: Evaluate whether the introduction builds a convincing argument for the paper's contribution and identifies the right gap.
**Source**: Section 1 (lines 170-220)
**Expected output**: Assessment of logical flow, gap identification quality, contribution clarity, positioning against prior work.
**What this tests**: Whether the writing/argument reviewer can assess narrative quality, whether it catches overclaiming in contributions list.

**Known issues**:
- The contributions list is long (6 sub-items across 2 main items) — could be consolidated
- Gap statement ("transferring LLM-SAEs to DLM-SAEs is not plug-and-play") is somewhat informal for a top venue
- Distinction from image-diffusion SAE work could be sharper

---

## C04 — Method Rigor Critique (Theory Core)

**Task**: Critically evaluate the mathematical formulations in Sections 2-3 for rigor, completeness, and soundness.
**Source**: Sections 2.1-3.2 (lines 224-540)
**Expected output**: Theory review assessing: whether equations are well-defined, assumptions stated, notation consistent, derivations sound, and whether the mathematical framework constitutes a genuine theoretical contribution.
**What this tests**: Theory reviewer depth and specificity.

**Known issues**:
- Equations 1-7 define existing frameworks (SAEs, DLMs) and propose training variants — these are engineering contributions, not theoretical ones
- The Mask-SAE vs Unmask-SAE distinction is a design choice, not a theorem
- No convergence guarantees, no bounds, no formal analysis of why early-layer insertion reduces loss
- Notation: $h$ is used for both generic SAE features and specific feature vectors without clear disambiguation
- The "negative delta-LM loss" phenomenon (Section 3.2) is observed but not explained

---

## C05 — Experiments Critique (Evidence Core)

**Task**: Critically evaluate all experimental claims, baselines, ablations, and results.
**Source**: Sections 3-6 + Tables 1-2 + Figures 3-6 (lines 369-720)
**Expected output**: Experiments review assessing: claim-number alignment, baseline fairness, ablation completeness, statistical credibility, reproducibility.
**What this tests**: Experiment reviewer depth and ability to catch unsupported claims.

**Known issues**:
- Steering comparison (Table 2): Dream/LLaDA use different steering strategies (All-tokens vs Update-tokens) — not perfectly controlled
- Decoding order analysis (Section 5): correlation between SAE dynamics and task performance is conjectured but not statistically tested
- GSM8K results: only 800 questions sampled, only Dream-7B tested for decoding order, no error bars reported
- Transfer results (Section 6): only Dream model tested, no LLaDA transfer experiments shown in main text
- No comparison against non-SAE interpretability methods
- Auto-interpretation scoring (Section 3.3): uses gpt-4o-mini as judge — potential bias; no human evaluation comparison

---

## C06 — Claim-Evidence Audit (Cross-Core)

**Task**: Map every claim in the abstract and introduction to supporting evidence (theorem, experiment, or figure), and flag unsupported claims.
**Source**: Abstract + Introduction + rest of paper
**Expected output**: Claim-evidence mapping table showing which claims are supported, partially supported, or unsupported.
**What this tests**: Cross-core coordination — whether the system can detect misalignment between claims and evidence.

**Known claims to audit**:
- "first SAE-based interpretability framework for DLMs" — supported by the work itself but "first" is hard to verify
- "SAE insertion can reduce cross-entropy loss" — supported by Figure 3
- "often outperforming LLM steering" — supported by Table 2 but comparison fairness is questionable
- "SAEs can provide useful signals for DLM decoding order" — stated as conjecture, not formally demonstrated
- "SAE features are stable during post-training phase" — supported by Figure 6 for Dream but not LLaDA
- "great potential of applying SAEs to DLM-related tasks" — aspirational, not directly evidenced

---

## C07 — Global Coherence Review

**Task**: Assess whether the paper tells a coherent story from abstract through conclusion, and whether all sections serve the main argument.
**Source**: Full paper
**Expected output**: Assessment of narrative coherence, section necessity, argument consistency, whether the paper would convince a skeptical reviewer.
**What this tests**: Whether the skill detects global-level weaknesses (sections that feel disconnected, contributions that don't align with conclusions).

**Known issues**:
- The paper has 4 distinct research questions (Sections 3-6) which may feel like separate studies stapled together
- Section 5 (decoding order) is the weakest link — it's exploratory and ends with a conjecture
- The "first" claim creates expectations for a foundational contribution, but the paper is more of an empirical feasibility study
- Discussion section is brief and doesn't deeply engage with limitations

---

## C08 — Section Rewrite: Discussion/Limitations

**Task**: Revise the Discussion section (Section 8) to be stronger, more honest about limitations, and more forward-looking.
**Source**: Discussion section (lines 739-741) + full paper context
**Expected output**: Revised discussion section with explicit limitation discussion, honest scope assessment, and actionable future directions.
**What this tests**: Writing agent quality, honesty about limitations, whether the skill promotes honest reporting.

**Known issues**:
- Current discussion is 4 sentences, very brief for a top-venue paper
- No explicit limitations subsection
- Does not discuss: limited model coverage (only Dream-7B, LLaDA-8B), lack of human evaluation, potential for SAE to miss important non-sparse features, scalability concerns

---

## C09 — Multi-Round Revision Verification

**Task**: Simulate checking whether a previously flagged issue (e.g., "Section 5 claims correlation without statistical evidence") was genuinely resolved in a revision.
**Source**: Section 5 (lines 612-681) — assume a revision was submitted that reworded the conjecture but added no new statistical analysis.
**Expected output**: Historical reviewer assessment showing the issue was NOT genuinely resolved (superficial fix detected).
**What this tests**: Anti-superficial-fix detection, Historical reviewer audit quality, issue tracking across rounds.

---

## C10 — Submission-Readiness Checklist

**Task**: Perform a final submission-readiness check for ICML 2026.
**Source**: Full paper
**Expected output**: Checklist covering: page limit compliance, reference completeness, anonymization, figure quality, code availability, venue format compliance, impact statement presence.
**What this tests**: Structure/reproducibility reviewer thoroughness.

**Known items to check**:
- Paper uses `\usepackage{icml2026}` — correct format
- Page count: main text appears to be ~8-9 pages (within ICML limit)
- Author names are placeholder (Firstname1, etc.) — anonymized for blind review
- Impact statement present
- Code availability: not mentioned in main text
- Some `\todo` notes may remain (todonotes package is loaded)
- Figure quality depends on PDF compilation

---

## C11 — Venue-Oriented Improvement Plan

**Task**: Given that this is targeted at ICML 2026, identify the 5 most impactful improvements to maximize acceptance probability.
**Source**: Full paper + ICML venue expectations
**Expected output**: Prioritized list of 5 improvements with specific actionable steps, severity, and expected impact on reviewer scores.
**What this tests**: Whether the aggregation mechanism produces actionable, prioritized improvement plans.

---

## C12 — Reproducibility Deep Audit

**Task**: Evaluate whether the paper provides sufficient information for an independent researcher to reproduce the main results.
**Source**: Full paper including appendices
**Expected output**: Reproducibility assessment covering: training details, hyperparameters, data access, hardware requirements, code availability, random seeds, evaluation protocols.
**What this tests**: Structure/reproducibility reviewer depth.

**Known items**:
- Appendix A provides training setup (batch size, context length, GPU type, token budget)
- Common Pile dataset is referenced but specific split details are sparse
- Steering evaluation uses 5 neutral prefixes with 30 tokens — details in appendix
- Auto-interpretation uses gpt-4o-mini as judge — external dependency
- No code repository mentioned
- No random seed specification in main text (mentioned as principle but specific seeds not given)
